using System.ComponentModel.DataAnnotations;

namespace Models;

public class Booking
{
    public int BookingId { get; set; }

    [Required(ErrorMessage = "Customer Name is required.")]
    public string CustomerName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email is required.")]
    [EmailAddress(ErrorMessage = "Enter a valid email address.")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Phone is required.")]
    [Phone(ErrorMessage = "Enter a valid phone number.")]
    public string Phone { get; set; } = string.Empty;

    [Required(ErrorMessage = "Movie ID is required.")]
    public int MovieId { get; set; }

    [Required(ErrorMessage = "Booking Date is required.")]
    public DateTime BookingDate { get; set; }

    [Required(ErrorMessage = "Show Date is required.")]
    public DateTime ShowDate { get; set; }

    [Range(1, 10, ErrorMessage = "Tickets must be between 1 and 10.")]
    public int NumberOfTickets { get; set; }

    public DateTime? CancellationDate { get; set; }
}