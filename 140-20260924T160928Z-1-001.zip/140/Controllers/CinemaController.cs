using System.Collections.Generic;

namespace Controllers;

public class CinemaController : Controller
{
    private static readonly List<Movie> Movies = new()
    {
        new Movie
        {
            MovieId = 1,
            MovieName = "Avengers: Endgame",
            Genre = "Action / Superhero",
            Language = "English",
            TicketPrice = 250,
            AvailableSeats = 80
        },

        new Movie
        {
            MovieId = 2,
            MovieName = "3 Idiots",
            Genre = "Comedy / Drama",
            Language = "Hindi",
            TicketPrice = 180,
            AvailableSeats = 100
        },

        new Movie
        {
            MovieId = 3,
            MovieName = "RRR",
            Genre = "Action / Drama",
            Language = "Telugu",
            TicketPrice = 220,
            AvailableSeats = 70
        },

        new Movie
        {
            MovieId = 4,
            MovieName = "Interstellar",
            Genre = "Science Fiction",
            Language = "English",
            TicketPrice = 300,
            AvailableSeats = 60
        }
    };

    private static readonly List<Booking> Bookings = new();

    public IActionResult Index()
    {
        return View(Bookings);
    }

    [HttpGet]
    public IActionResult BookTicket()
    {
        Booking booking = new Booking
        {
            BookingDate = DateTime.Today,
            ShowDate = DateTime.Today.AddDays(1),
            NumberOfTickets = 1
        };

        return View(booking);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult BookTicket(Booking booking)
    {
        if (!ModelState.IsValid)
        {
            return View(booking);
        }

        Movie? movie = Movies.FirstOrDefault(
            m => m.MovieId == booking.MovieId);

        if (movie == null)
        {
            ModelState.AddModelError(
                "MovieId",
                "Movie ID does not exist.");

            return View(booking);
        }

        if (booking.NumberOfTickets > movie.AvailableSeats)
        {
            ModelState.AddModelError(
                "NumberOfTickets",
                $"Only {movie.AvailableSeats} seats are available.");

            return View(booking);
        }

        booking.BookingId = Bookings.Count + 1;

        Bookings.Add(booking);

        movie.AvailableSeats -= booking.NumberOfTickets;

        TempData["SuccessMessage"] =
            "Your movie ticket has been booked successfully!";

        return RedirectToAction(nameof(Index));
    }

    public IActionResult MovieDetails(int id)
    {
        Booking? booking = Bookings.FirstOrDefault(
            b => b.BookingId == id);

        if (booking == null)
        {
            return NotFound();
        }

        return View(booking);
    }

    public IActionResult About()
    {
        return View();
    }

    public IActionResult Cancel(int id)
    {
        Booking? booking = Bookings.FirstOrDefault(
            b => b.BookingId == id);

        if (booking == null)
        {
            return NotFound();
        }

        if (!booking.CancellationDate.HasValue)
        {
            booking.CancellationDate = DateTime.Now;
        }

        return RedirectToAction(nameof(Index));
    }

    public static Movie? GetMovie(int movieId)
    {
        return Movies.FirstOrDefault(
            m => m.MovieId == movieId);
    }
}