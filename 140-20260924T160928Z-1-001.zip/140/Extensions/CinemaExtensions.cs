using Models;

namespace Extensions;

public static class CinemaExtensions
{
    public static string GetBookingStatus(this Booking booking)
    {
        if (booking.CancellationDate.HasValue)
        {
            return "Cancelled";
        }

        DateTime today = DateTime.Today;
        DateTime showDate = booking.ShowDate.Date;

        if (showDate < today)
        {
            return "Completed";
        }

        if (showDate == today)
        {
            return "Today";
        }

        return "Upcoming";
    }

    public static decimal CalculateTotalAmount(
        this Booking booking,
        Movie movie)
    {
        return booking.NumberOfTickets * movie.TicketPrice;
    }
}